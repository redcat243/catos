hi this is catos a funny terminal thing for your terminal it works on mac you
just need to run these commands below this lin and they are:
oh wait first do this nano ~/.zshrc
then copy one line of each and put it on one line per each alias
alias change-cat-folder="cd"
alias cat-cat-folder="mkdir"
alias pounce="rm -rf"
alias cat-cat-file="touch"
alias cat-edit="nano"
alias cat-read="less"
alias cat-move="mv"
alias cat-list="ls"
and then to refresh run source ~/.zshrc
you can also add this too (only works if you have python 3.14):
alias catos="python3.14 ~/Desktop/catos-terminal/catoscli.py"
also move this folder to your desktop