import time
import subprocess
import os

# Changes the active directory to your specific folder right when the script starts
try:
    os.chdir(os.path.expanduser("~/Desktop/catos-terminal"))
except Exception as e:
    print(f"Startup folder error: {e}")

time.sleep(10)
subprocess.run("afplay -v 10 ~/Desktop/catos-terminal/start.mp3", shell=True)
time.sleep(5)

print("welcome to cat os")
print("the commands are:")
print("change-cat-folder changes the folder you are in")
print("cat-cat-folder makes a new folder")
print("pounce deleats the folder selected and all the files in it")
print("cat-cat-file makes a new file")
print("pounce still delets the thing selected")
print("cat-edit edits the file selected")
print("cat-read reads the file selected")
print("cat-move moves or renames the file or folder selected to the folder after the command (but when renameing you dont have to put where it should go at the end just put the filename) and for the folder you want to move the file/folder you just have to put it after the file to move but surround them in quotes but i cannot show a example")
print("cat-copy copies the file or folder after the command (suronded by quotes but i cannot show a example) to the folder after the file/folder to copy")
print("cat-list lists the files and folders in the folder selected")
print("thats all the commands for now")
print("oh i also almost forgot the commands exit witch exits and help which shows the commands again oh + when reading press q to come back to the terminal")

while True:
    cmd = input("catos >")
    
    if cmd == "help":
        print("the commands are:")
        print("change-cat-folder changes the folder you are in")
        print("cat-cat-folder makes a new folder")
        print("pounce deleats the folder selected and all the files in it")
        print("cat-cat-file makes a new file")
        print("pounce still delets the thing selected")
        print("cat-edit edits the file selected")
        print("cat-read reads the file selected")
        print("cat-move moves or renames the file or folder selected to the folder after the command (but when renameing you dont have to put where it should go at the end just put the filename) and for the folder you want to move the file/folder you just have to put it after the file to move but surround them in quotes but i cannot show a example")
        print("cat-copy copies the file or folder after the command (surrounded by quotes but i cannot show a example) to the folder after the file/folder to copy")
        print("cat-list lists the files and folders in the folder selected")
    elif cmd == "exit":
        break
    elif cmd == "change-cat-folder":
        target = input("Folder to change to: ").strip().strip('"\'')
        
        # 2. Check if they left it blank
        if target == "":
            print("please specify the folder")
        else:
            import os
            try:
                # os.path.expanduser safely handles home directory paths like '~'
                os.chdir(os.path.expanduser(target))
            except Exception as e:
                print(f"Error changing folder: {e}")

    elif cmd == "cat-cat-folder":
        print("please specify the name of the folder")
    elif cmd == "pounce":
        print("please specify the file or folder you want to delete")
    elif cmd == "cat-cat-file":
        print("please specify the name of the file")
    elif cmd == "cat-edit":
        print("please specify the file you want to edit")
    elif cmd == "cat-read":
        print("please specify the file you want to read")
    elif cmd == "cat-move":
        print("please specify the file or folder you want to move and where you want to move it to (but when renameing you dont have to put where it should go at the end just put the filename) and for the folder you want to move the file/folder you just have to put it after the file to move but surround them in quotes but i cannot show a example")
    elif cmd == "cat-copy":
        print("please specify the file or folder you want to copy and where you want to copy it to (surrounded by quotes but i cannot show a example)")
    elif cmd == "":
        print("please enter a command")
        
    # 2. Elif blocks that handle the actual execution when the user passes information
    elif cmd.startswith("change-cat-folder "):
        folder_path = cmd.replace("change-cat-folder ", "", 1).strip().strip('"\'')
        try:
            os.chdir(os.path.expanduser(folder_path))
        except Exception as e:
            print(f"Error: {e}")
    elif cmd.startswith("cat-list"):
        zsh_cmd = cmd.replace("cat-list", "ls", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("cat-cat-folder "):
        zsh_cmd = cmd.replace("cat-cat-folder ", "mkdir ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("cat-cat-file "):
        zsh_cmd = cmd.replace("cat-cat-file ", "touch ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("pounce "):
        zsh_cmd = cmd.replace("pounce ", "rm -rf ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("cat-read "):
        zsh_cmd = cmd.replace("cat-read ", "less ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("cat-edit "):
        zsh_cmd = cmd.replace("cat-edit ", "nano ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("cat-move "):
        zsh_cmd = cmd.replace("cat-move ", "mv ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
    elif cmd.startswith("cat-copy "):
        zsh_cmd = cmd.replace("cat-copy ", "cp -r ", 1)
        subprocess.run(zsh_cmd, shell=True, executable="/bin/zsh")
        
    # 3. Final fallback else: Runs any standard Zsh command normally
    else:
        # Uses executable="/bin/zsh" to load your environment and prevent the tty freeze
        full_command = f"[ -f ~/.zshrc ] && source ~/.zshrc; {cmd}"
        subprocess.run(full_command, shell=True, executable="/bin/zsh")
